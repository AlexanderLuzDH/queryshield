"""Test runner integrations for QueryShield SQLAlchemy probe"""

__all__ = ["pytest_plugin"]
